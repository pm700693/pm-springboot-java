package com.conf.avro.schema;

public class StockHistoryJson {

	public int tradeId;
	   public int tradeQuantity;
	   public String tradeMarket;
	   public String stockName;
	   public String tradeType;
	   public float price;
	   public float amount;
	public int getTradeId() {
		return tradeId;
	}
	public void setTradeId(int tradeId) {
		this.tradeId = tradeId;
	}
	public int getTradeQuantity() {
		return tradeQuantity;
	}
	public void setTradeQuantity(int tradeQuantity) {
		this.tradeQuantity = tradeQuantity;
	}
	public String getTradeMarket() {
		return tradeMarket;
	}
	public void setTradeMarket(String tradeMarket) {
		this.tradeMarket = tradeMarket;
	}
	public String getStockName() {
		return stockName;
	}
	public void setStockName(String stockName) {
		this.stockName = stockName;
	}
	public String getTradeType() {
		return tradeType;
	}
	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public StockHistoryJson() {
		super();
		// TODO Auto-generated constructor stub
	}
	public StockHistoryJson(int tradeId, int tradeQuantity, String tradeMarket, String stockName, String tradeType,
			float price, float amount) {
		super();
		this.tradeId = tradeId;
		this.tradeQuantity = tradeQuantity;
		this.tradeMarket = tradeMarket;
		this.stockName = stockName;
		this.tradeType = tradeType;
		this.price = price;
		this.amount = amount;
	}

}
