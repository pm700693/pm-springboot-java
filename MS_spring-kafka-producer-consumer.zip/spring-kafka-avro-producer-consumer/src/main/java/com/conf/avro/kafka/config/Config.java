package com.conf.avro.kafka.config;

import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;

import com.conf.avro.schema.StockHistory;
import com.conf.avro.schema.StockHistoryJson;

@Configuration
public class Config {

    @Bean
    public ConsumerFactory<String, StockHistory> consumerFactory(KafkaProperties kafkaProperties) {
        return new DefaultKafkaConsumerFactory<>(kafkaProperties.buildConsumerProperties());
    }
    @Bean
    public ConsumerFactory<String, StockHistoryJson> consumerFactory1(KafkaProperties kafkaProperties) {
        return new DefaultKafkaConsumerFactory<>(kafkaProperties.buildConsumerProperties());
    }
    @Bean
    public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, StockHistory>> kafkaListenerContainerFactory(KafkaProperties kafkaProperties) {
        ConcurrentKafkaListenerContainerFactory<String, StockHistory> factory = new ConcurrentKafkaListenerContainerFactory<String, StockHistory>();
        factory.setConsumerFactory(consumerFactory(kafkaProperties));
        return factory;
    }
    @Bean
    public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, StockHistoryJson>> kafkaListenerContainerFactory1(KafkaProperties kafkaProperties) {
        ConcurrentKafkaListenerContainerFactory<String, StockHistoryJson> factory = new ConcurrentKafkaListenerContainerFactory<String, StockHistoryJson>();
        factory.setConsumerFactory(consumerFactory1(kafkaProperties));
        return factory;
    }
}
