package com.conf.avro.kafka.controller;

import com.conf.avro.kafka.model.StockHistoryModel;
import com.conf.avro.kafka.producer.SpringAvroProducer;
import com.conf.avro.schema.StockHistory;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Random;

@Tag(
        name = "CRUD REST APIs for User Resource",
        description = "CRUD REST APIs"
)

@RestController
@RequestMapping("kafka")
public class SpringAvroRestController {

    @Autowired
    private SpringAvroProducer springAvroProducer;
    
    @Operation(
            summary = "Get for Rest Check",
            description = "Get for Rest Check"
    )
    @ApiResponse(
            responseCode = "201",
            description = "Working Condition"
    )
    @GetMapping(value ="/getTest")
    public void getTest() {
    	System.out.println("Looking Fine");
    }

    @PostMapping(value = "/sendStockHistory")
    public void sendStockHistory(@RequestBody StockHistoryModel model){
        StockHistory stockHistory= StockHistory.newBuilder().build();
        stockHistory.setStockName(model.getStockName());
        stockHistory.setTradeType(model.getTradeType());
        stockHistory.setPrice(model.getPrice());
        stockHistory.setAmount(model.getAmount());
        stockHistory.setTradeId(new Random(1000).nextInt());
        stockHistory.setTradeMarket(model.getTradeMarket());
        stockHistory.setTradeQuantity(model.getTradeQuantity());
        springAvroProducer.send(stockHistory);
    }
    
    @PostMapping(value = "/sendJson")
    public void sendJson(@RequestBody StockHistoryModel model){
        StockHistory stockHistory= StockHistory.newBuilder().build();
        stockHistory.setStockName(model.getStockName());
        stockHistory.setTradeType(model.getTradeType());
        stockHistory.setPrice(model.getPrice());
        stockHistory.setAmount(model.getAmount());
        stockHistory.setTradeId(new Random(1000).nextInt());
        stockHistory.setTradeMarket(model.getTradeMarket());
        stockHistory.setTradeQuantity(model.getTradeQuantity());
        springAvroProducer.send(stockHistory);
    }
}
