package com.conf.avro.kafka.producer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

import com.conf.avro.schema.StockHistory;
import com.conf.avro.schema.StockHistoryJson;

@Service
public class SpringAvroProducer {

    @Value("${avro.topic.name}")
    String topicName;

    @Autowired
    private KafkaTemplate<String, StockHistory> kafkaTemplate;
    
    @Autowired
    private KafkaTemplate<String, StockHistoryJson> kafkaTemplate1;

    
    public void send(StockHistory stockHistory){
       ListenableFuture<SendResult<String,StockHistory>> future=  kafkaTemplate.send(topicName,String.valueOf(stockHistory.getTradeId()),stockHistory);
       future.addCallback(new ListenableFutureCallback<SendResult<String, StockHistory>>() {
           @Override
           public void onFailure(Throwable ex) {
               System.out.println("Message failed to produce");
           }

           @Override
           public void onSuccess(SendResult<String, StockHistory> result) {
               System.out.println("Avro message successfully produced");
           }
       });

    }
    
    public void send(StockHistoryJson stockHistoryJson){
        ListenableFuture<SendResult<String,StockHistoryJson>> future=  kafkaTemplate1.send(topicName,String.valueOf(stockHistoryJson.getTradeId()),stockHistoryJson);
        future.addCallback(new ListenableFutureCallback<SendResult<String, StockHistoryJson>>() {
            @Override
            public void onFailure(Throwable ex) {
                System.out.println("Message failed to produce");
            }

            @Override
            public void onSuccess(SendResult<String, StockHistoryJson> result) {
                System.out.println("Json message successfully produced");
            }
        });

     }

}
