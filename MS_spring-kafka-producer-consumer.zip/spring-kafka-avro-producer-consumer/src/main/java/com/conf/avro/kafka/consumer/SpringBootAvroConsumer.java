package com.conf.avro.kafka.consumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.conf.avro.schema.StockHistory;
import com.conf.avro.schema.StockHistoryJson;

@Service
public class SpringBootAvroConsumer {

    @KafkaListener(topics = "${avro.topic.name}", containerFactory = "kafkaListenerContainerFactory")
    public void read(ConsumerRecord<String, StockHistory> record){
        String key=record.key();
        StockHistory history=record.value();
        System.out.println("Avro message received for key : "+key+ " value : "+history.toString());
    }
    
    @KafkaListener(topics = "${avro.topic.name}", containerFactory = "kafkaListenerContainerFactory1")
    public void read1(ConsumerRecord<String, StockHistoryJson> record){
        String key=record.key();
        StockHistoryJson history=record.value();
        System.out.println("Avro message received for key : "+key+ " value : "+history.toString());
    }
    
    
    

}
